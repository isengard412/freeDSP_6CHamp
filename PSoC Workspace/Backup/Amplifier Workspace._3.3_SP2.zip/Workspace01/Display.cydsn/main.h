/*******************************************************************************
* File Name: main.h
*
* Version: 0.0
*
* author: Lukas Creutzburg
*
*******************************************************************************/

#if !defined(CY_MAIN_H)
#define CY_MAIN_H

#include <project.h>
#include "ILI9341.h"


#endif /* (CY_MAIN_H) */
/* [] END OF FILE */
