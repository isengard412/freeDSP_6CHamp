/*******************************************************************************
* File Name: Protection_IN.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Protection_IN_H) /* Pins Protection_IN_H */
#define CY_PINS_Protection_IN_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Protection_IN_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Protection_IN__PORT == 15 && ((Protection_IN__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Protection_IN_Write(uint8 value);
void    Protection_IN_SetDriveMode(uint8 mode);
uint8   Protection_IN_ReadDataReg(void);
uint8   Protection_IN_Read(void);
void    Protection_IN_SetInterruptMode(uint16 position, uint16 mode);
uint8   Protection_IN_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Protection_IN_SetDriveMode() function.
     *  @{
     */
        #define Protection_IN_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Protection_IN_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Protection_IN_DM_RES_UP          PIN_DM_RES_UP
        #define Protection_IN_DM_RES_DWN         PIN_DM_RES_DWN
        #define Protection_IN_DM_OD_LO           PIN_DM_OD_LO
        #define Protection_IN_DM_OD_HI           PIN_DM_OD_HI
        #define Protection_IN_DM_STRONG          PIN_DM_STRONG
        #define Protection_IN_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Protection_IN_MASK               Protection_IN__MASK
#define Protection_IN_SHIFT              Protection_IN__SHIFT
#define Protection_IN_WIDTH              1u

/* Interrupt constants */
#if defined(Protection_IN__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Protection_IN_SetInterruptMode() function.
     *  @{
     */
        #define Protection_IN_INTR_NONE      (uint16)(0x0000u)
        #define Protection_IN_INTR_RISING    (uint16)(0x0001u)
        #define Protection_IN_INTR_FALLING   (uint16)(0x0002u)
        #define Protection_IN_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Protection_IN_INTR_MASK      (0x01u) 
#endif /* (Protection_IN__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Protection_IN_PS                     (* (reg8 *) Protection_IN__PS)
/* Data Register */
#define Protection_IN_DR                     (* (reg8 *) Protection_IN__DR)
/* Port Number */
#define Protection_IN_PRT_NUM                (* (reg8 *) Protection_IN__PRT) 
/* Connect to Analog Globals */                                                  
#define Protection_IN_AG                     (* (reg8 *) Protection_IN__AG)                       
/* Analog MUX bux enable */
#define Protection_IN_AMUX                   (* (reg8 *) Protection_IN__AMUX) 
/* Bidirectional Enable */                                                        
#define Protection_IN_BIE                    (* (reg8 *) Protection_IN__BIE)
/* Bit-mask for Aliased Register Access */
#define Protection_IN_BIT_MASK               (* (reg8 *) Protection_IN__BIT_MASK)
/* Bypass Enable */
#define Protection_IN_BYP                    (* (reg8 *) Protection_IN__BYP)
/* Port wide control signals */                                                   
#define Protection_IN_CTL                    (* (reg8 *) Protection_IN__CTL)
/* Drive Modes */
#define Protection_IN_DM0                    (* (reg8 *) Protection_IN__DM0) 
#define Protection_IN_DM1                    (* (reg8 *) Protection_IN__DM1)
#define Protection_IN_DM2                    (* (reg8 *) Protection_IN__DM2) 
/* Input Buffer Disable Override */
#define Protection_IN_INP_DIS                (* (reg8 *) Protection_IN__INP_DIS)
/* LCD Common or Segment Drive */
#define Protection_IN_LCD_COM_SEG            (* (reg8 *) Protection_IN__LCD_COM_SEG)
/* Enable Segment LCD */
#define Protection_IN_LCD_EN                 (* (reg8 *) Protection_IN__LCD_EN)
/* Slew Rate Control */
#define Protection_IN_SLW                    (* (reg8 *) Protection_IN__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Protection_IN_PRTDSI__CAPS_SEL       (* (reg8 *) Protection_IN__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Protection_IN_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Protection_IN__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Protection_IN_PRTDSI__OE_SEL0        (* (reg8 *) Protection_IN__PRTDSI__OE_SEL0) 
#define Protection_IN_PRTDSI__OE_SEL1        (* (reg8 *) Protection_IN__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Protection_IN_PRTDSI__OUT_SEL0       (* (reg8 *) Protection_IN__PRTDSI__OUT_SEL0) 
#define Protection_IN_PRTDSI__OUT_SEL1       (* (reg8 *) Protection_IN__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Protection_IN_PRTDSI__SYNC_OUT       (* (reg8 *) Protection_IN__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Protection_IN__SIO_CFG)
    #define Protection_IN_SIO_HYST_EN        (* (reg8 *) Protection_IN__SIO_HYST_EN)
    #define Protection_IN_SIO_REG_HIFREQ     (* (reg8 *) Protection_IN__SIO_REG_HIFREQ)
    #define Protection_IN_SIO_CFG            (* (reg8 *) Protection_IN__SIO_CFG)
    #define Protection_IN_SIO_DIFF           (* (reg8 *) Protection_IN__SIO_DIFF)
#endif /* (Protection_IN__SIO_CFG) */

/* Interrupt Registers */
#if defined(Protection_IN__INTSTAT)
    #define Protection_IN_INTSTAT            (* (reg8 *) Protection_IN__INTSTAT)
    #define Protection_IN_SNAP               (* (reg8 *) Protection_IN__SNAP)
    
	#define Protection_IN_0_INTTYPE_REG 		(* (reg8 *) Protection_IN__0__INTTYPE)
#endif /* (Protection_IN__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Protection_IN_H */


/* [] END OF FILE */
